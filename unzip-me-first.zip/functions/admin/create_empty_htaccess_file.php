<?php
$full_htaccess_config = "
 ##Redirect 404 to homepage
 ErrorDocument 404 /index.php
";
?>